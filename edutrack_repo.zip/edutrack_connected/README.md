# EduTrack Academy Management System

A full-stack academy management engine built with a **Python CLI + REST API backend** and a **React + Tailwind frontend** exported from Figma.

---

## Project Structure

```
edutrack/
├── edutrack.py              # Core Python backend (OOP, file persistence)
├── server.py                # Standard-library REST API server (no pip needed)
├── test_edutrack.py         # Unit tests — all PRD validation cases (VAL-01–VAL-04)
├── edutrack-api-client.js   # Vanilla JS API client for HTML frontends
├── database.json            # Auto-generated persistent data store
│
├── src/                     # React frontend (Figma export)
│   ├── app/
│   │   ├── api.ts           # TypeScript API service layer → talks to server.py
│   │   ├── App.tsx          # Root component + view routing
│   │   └── components/
│   │       ├── Dashboard.tsx
│   │       ├── Students.tsx
│   │       ├── Grades.tsx
│   │       ├── Attendance.tsx
│   │       ├── Assignments.tsx
│   │       ├── Reports.tsx
│   │       └── Sidebar.tsx
│   └── styles/
│
├── package.json
└── vite.config.ts
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend language | Python 3.8+ (standard library only — zero pip installs) |
| Data persistence | JSON flat-file (`database.json`) |
| API server | `http.server` (built-in) |
| Frontend framework | React 18 + TypeScript |
| Styling | Tailwind CSS v4 + shadcn/ui components |
| Charts | Recharts |
| Build tool | Vite |
| Design source | Figma (exported via Make) |

---

## Getting Started

### 1. Run the Python backend

```bash
python server.py
```

Server starts at **http://localhost:8000**. Keep this terminal open.

To use the CLI directly:

```bash
python edutrack.py
```

### 2. Run the frontend

```bash
npm install   # or: pnpm install
npm run dev   # or: pnpm dev
```

Open **http://localhost:5173**. Make sure `server.py` is running first.

### 3. Run the tests

```bash
python test_edutrack.py
```

All 12 tests should pass ✅

---

## API Reference

All endpoints at `http://localhost:8000`:

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/students` | List all students |
| `GET` | `/students/:id` | Get one student |
| `GET` | `/honours` | Students with GPA ≥ 3.5 |
| `GET` | `/stats` | Dashboard summary numbers |
| `POST` | `/students` | Add student `{ user_id, name, email }` |
| `POST` | `/students/:id/grades` | Add grade `{ subject, score }` |
| `POST` | `/students/:id/attendance` | Mark attendance `{ date? }` |
| `POST` | `/students/:id/courses` | Enrol in course `{ course }` |
| `POST` | `/students/:id/curve` | Apply grade curve `{ bonus }` |
| `POST` | `/save` | Force-save database to disk |
| `DELETE` | `/students/:id` | Remove a student |

---

## PRD Requirements Coverage

| REQ | Concept | Implementation |
|---|---|---|
| REQ-01 | OOP Base class | `class User` — `user_id`, `name`, `email` |
| REQ-02 | Inheritance | `class Student(User)` — courses (list), attendance (set), grades (dict) |
| REQ-03 | Encapsulation | `__grades` private, validates 0.0–100.0, raises `ValueError` |
| REQ-04 | Polymorphism | `get_dashboard()` overrides parent method |
| REQ-05 | GPA formula | `(Σ scores / count) / 100 × 4.0` |
| REQ-06 | Functional programming | `apply_curve()` uses `map()` + `lambda`, capped at 100 |
| REQ-07 | List comprehension | `get_honours_list()` filters GPA ≥ 3.5 |
| REQ-08 | Decorator | `@log_action` closure with timestamped audit logs |
| REQ-09 | Error handling | `try/except` wraps entire CLI loop |
| REQ-10 | Generator | `student_profile_generator()` uses `yield` |
| REQ-11 | File load | Decodes JSON, casts lists → Python sets |
| REQ-12 | File save | Marshals state to indented JSON via `with open()` |

---

## Validation Tests (VAL-01–VAL-04)

| Test | Verifies |
|---|---|
| VAL-01 | Non-numeric grade input raises `ValueError` |
| VAL-02 | Duplicate attendance dates stored only once |
| VAL-03 | Scores 100 + 50 → GPA = 3.00 exactly |
| VAL-04 | Save + reload reconstructs full state from `database.json` |

---

## License

MIT
