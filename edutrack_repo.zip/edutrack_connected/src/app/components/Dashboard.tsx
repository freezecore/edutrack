import { useEffect, useState } from "react";
import {
  Users, ClipboardCheck, TrendingUp, Award,
  ArrowUp, ArrowDown, Bell, BookOpen,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";
import { api, Student, Stats, scoreToLetter, attendanceRate } from "../api";

const PIE_COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"];

// Static chart data (structural / historical - not from live registry)
const attendanceData = [
  { month: "Sep", rate: 94 }, { month: "Oct", rate: 91 },
  { month: "Nov", rate: 88 }, { month: "Dec", rate: 85 },
  { month: "Jan", rate: 90 }, { month: "Feb", rate: 93 },
  { month: "Mar", rate: 96 },
];

export function Dashboard() {
  const [students, setStudents] = useState<Student[]>([]);
  const [stats, setStats]       = useState<Stats | null>(null);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.getAllStudents(), api.getStats()])
      .then(([s, st]) => { setStudents(s); setStats(st); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  // Derived data from live students
  const topStudents = [...students]
    .sort((a, b) => b.gpa - a.gpa)
    .slice(0, 4);

  const gradeDistribution = ["A", "B", "C", "D", "F"].map((letter) => ({
    grade: letter,
    count: students.reduce((acc, s) => {
      const scores = Object.values(s.grades);
      return acc + scores.filter((sc) => scoreToLetter(sc).startsWith(letter)).length;
    }, 0),
  }));

  const subjectMap: Record<string, number[]> = {};
  students.forEach((s) => {
    Object.entries(s.grades).forEach(([sub, score]) => {
      if (!subjectMap[sub]) subjectMap[sub] = [];
      subjectMap[sub].push(score);
    });
  });
  const subjectPerformance = Object.entries(subjectMap)
    .map(([subject, scores]) => ({
      subject: subject.slice(0, 7),
      value: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length),
    }))
    .slice(0, 5);

  const recentActivity = students.slice(-5).flatMap((s) =>
    Object.entries(s.grades).slice(-1).map(([sub, score]) => ({
      text: `${s.name} scored ${score} in ${sub}`,
      time: "recently",
      color: score >= 80 ? "bg-green-500" : score >= 60 ? "bg-orange-500" : "bg-red-500",
    }))
  );

  const statCards = stats ? [
    { title: "Total Students",  value: String(stats.total_students),  change: "", changeLabel: "registered", trend: "up",   icon: Users,         color: "text-blue-600",   bg: "bg-blue-50" },
    { title: "Avg Attendance",  value: "—",                           change: "", changeLabel: "this term",  trend: "up",   icon: ClipboardCheck, color: "text-green-600",  bg: "bg-green-50" },
    { title: "Avg GPA",         value: stats.average_gpa.toFixed(2),  change: "", changeLabel: "/ 4.0",     trend: "up",   icon: TrendingUp,     color: "text-purple-600", bg: "bg-purple-50" },
    { title: "Honours",         value: String(stats.honours_count),   change: "", changeLabel: "GPA ≥ 3.5", trend: "up",   icon: Award,          color: "text-orange-600", bg: "bg-orange-50" },
  ] : [];

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground text-sm">Loading dashboard…</div>;
  if (error)   return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <div className="text-red-500 text-sm font-medium">Could not connect to EduTrack server</div>
      <div className="text-muted-foreground text-xs">Make sure <code className="bg-accent px-1 rounded">python server.py</code> is running at localhost:8000</div>
      <div className="text-xs text-red-400">{error}</div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-foreground">Dashboard Overview</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Live data from EduTrack</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="relative p-2 rounded-lg hover:bg-accent transition-colors">
            <Bell className="w-5 h-5 text-muted-foreground" />
          </button>
          <div className="flex items-center gap-2 ml-2">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-semibold">AP</div>
            <div className="text-sm">
              <div className="text-foreground leading-tight">Admin Principal</div>
              <div className="text-muted-foreground text-xs">Administrator</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.title} className="border-border">
              <CardContent className="pt-5 pb-4 px-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-muted-foreground">{card.title}</span>
                  <div className={`w-9 h-9 rounded-lg ${card.bg} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${card.color}`} />
                  </div>
                </div>
                <div className="text-2xl text-foreground mb-1">{card.value}</div>
                <div className="text-xs text-muted-foreground">{card.changeLabel}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="col-span-2 border-border">
          <CardHeader className="pb-2"><CardTitle className="text-base">Attendance Trend</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={attendanceData}>
                <defs>
                  <linearGradient id="attendGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis domain={[80, 100]} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v) => [`${v}%`, "Attendance"]} />
                <Area type="monotone" dataKey="rate" stroke="#3b82f6" strokeWidth={2} fill="url(#attendGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2"><CardTitle className="text-base">Grade Distribution (live)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={gradeDistribution} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="grade" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="border-border">
          <CardHeader className="pb-2"><CardTitle className="text-base">Subject Avg Scores (live)</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {subjectPerformance.length ? subjectPerformance.map((s) => (
              <div key={s.subject}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-foreground">{s.subject}</span>
                  <span className="text-muted-foreground">{s.value}%</span>
                </div>
                <Progress value={s.value} className="h-1.5" />
              </div>
            )) : <p className="text-xs text-muted-foreground">No grade data yet.</p>}
          </CardContent>
        </Card>

        <Card className="col-span-2 border-border">
          <CardHeader className="pb-2"><CardTitle className="text-base">Recent Grade Activity (live)</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {recentActivity.length ? recentActivity.map((a, i) => (
              <div key={i} className="flex gap-3 items-start">
                <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${a.color}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-foreground leading-snug">{a.text}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{a.time}</p>
                </div>
              </div>
            )) : <p className="text-xs text-muted-foreground">No recent activity.</p>}
          </CardContent>
        </Card>
      </div>

      {/* Top Students */}
      <Card className="border-border">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Top Performing Students (live)</CardTitle>
            <Badge variant="secondary" className="text-xs">Honours ≥ 3.5</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {topStudents.length ? (
            <div className="grid grid-cols-4 gap-4">
              {topStudents.map((s, i) => (
                <div key={s.user_id} className="flex items-center gap-3 p-3 rounded-lg bg-accent/50">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-semibold shrink-0">
                    {i + 1}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm text-foreground truncate">{s.name}</p>
                    <p className="text-xs text-muted-foreground">{s.user_id} · GPA {s.gpa.toFixed(2)}</p>
                  </div>
                  {s.gpa >= 3.5 && <ArrowUp className="w-4 h-4 text-green-500 ml-auto shrink-0" />}
                </div>
              ))}
            </div>
          ) : <p className="text-xs text-muted-foreground">No students in registry yet.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
