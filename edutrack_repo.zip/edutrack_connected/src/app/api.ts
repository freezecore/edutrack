/**
 * EduTrack API Service
 * All communication with the Python server (http://localhost:8000) goes here.
 * Import { api } into any component that needs live data.
 */

const BASE = "http://localhost:8000";

// ─── Types that mirror your Python Student dataclass ─────────────────────────

export interface Student {
  user_id: string;
  name: string;
  email: string;
  courses: string[];
  attendance: string[];          // sorted ISO date strings
  grades: Record<string, number>; // { "Mathematics": 92.0, ... }
  gpa: number;                   // pre-computed by server (0.0 – 4.0)
}

export interface Stats {
  total_students: number;
  average_gpa: number;
  honours_count: number;
  total_enrolments: number;
}

export interface ApiError {
  error: string;
}

// ─── Low-level fetch helper ───────────────────────────────────────────────────

async function req<T>(method: string, path: string, body?: unknown): Promise<T> {
  const opts: RequestInit = {
    method,
    headers: { "Content-Type": "application/json" },
  };
  if (body !== undefined) opts.body = JSON.stringify(body);

  const res = await fetch(BASE + path, opts);
  const data = await res.json();
  if (!res.ok) throw new Error((data as ApiError).error ?? "Request failed");
  return data as T;
}

// ─── API surface ─────────────────────────────────────────────────────────────

export const api = {

  // READ
  getAllStudents: ()                  => req<Student[]>("GET",    "/students"),
  getStudent:    (id: string)        => req<Student> ("GET",    `/students/${id}`),
  getHonours:    ()                  => req<Student[]>("GET",    "/honours"),
  getStats:      ()                  => req<Stats>   ("GET",    "/stats"),

  // WRITE
  addStudent: (user_id: string, name: string, email: string) =>
    req<Student>("POST", "/students", { user_id, name, email }),

  addGrade: (id: string, subject: string, score: number) =>
    req<Student>("POST", `/students/${id}/grades`, { subject, score }),

  markAttendance: (id: string, date?: string) =>
    req<Student>("POST", `/students/${id}/attendance`, date ? { date } : {}),

  enrolCourse: (id: string, course: string) =>
    req<Student>("POST", `/students/${id}/courses`, { course }),

  applyCurve: (id: string, bonus: number) =>
    req<Student>("POST", `/students/${id}/curve`, { bonus }),

  save: () =>
    req<{ message: string }>("POST", "/save"),

  // DELETE
  deleteStudent: (id: string) =>
    req<{ message: string }>("DELETE", `/students/${id}`),
};

// ─── Utility: derive letter grade from numeric score ─────────────────────────

export function scoreToLetter(score: number): string {
  if (score >= 97) return "A+";
  if (score >= 93) return "A";
  if (score >= 90) return "A-";
  if (score >= 87) return "B+";
  if (score >= 83) return "B";
  if (score >= 80) return "B-";
  if (score >= 77) return "C+";
  if (score >= 73) return "C";
  if (score >= 70) return "C-";
  if (score >= 67) return "D+";
  if (score >= 60) return "D";
  return "F";
}

// ─── Utility: attendance rate from date array ─────────────────────────────────

export function attendanceRate(dates: string[]): number {
  // Simple proxy: (days attended / 30 school days) * 100, capped at 100
  return Math.min(Math.round((dates.length / 30) * 100), 100);
}
