"""
EduTrack REST API Server
Wraps edutrack.py into a local HTTP server using ONLY the Python standard library.

Usage:
    python server.py

Server runs at:  http://localhost:8000
"""

import json
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# Import everything from your existing edutrack module
from edutrack import Student, get_honours_list, load_database, save_database


# ─────────────────────────────────────────────
# Shared in-memory registry (loaded from disk on startup)
# ─────────────────────────────────────────────
registry = load_database()


# ─────────────────────────────────────────────
# Helper: serialise a Student to a plain dict
# ─────────────────────────────────────────────
def student_to_json(s: Student) -> dict:
    return {
        "user_id":    s.user_id,
        "name":       s.name,
        "email":      s.email,
        "courses":    s.courses,
        "attendance": sorted(list(s.attendance)),
        "grades":     s.get_grades(),
        "gpa":        round(s.calculate_gpa(), 2),
    }


# ─────────────────────────────────────────────
# Request handler
# ─────────────────────────────────────────────
class EduTrackHandler(BaseHTTPRequestHandler):

    # ── Silence default request logging (optional: remove to see raw logs) ──
    def log_message(self, format, *args):
        print(f"  [SERVER] {self.address_string()} {format % args}")

    # ── CORS headers so your Figma-exported HTML can call this server ──────
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _respond(self, status: int, payload: dict | list):
        body = json.dumps(payload, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length))

    # ── Handle pre-flight CORS requests from browsers ──────────────────────
    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    # ──────────────────────────────────────────
    # GET  routes
    # ──────────────────────────────────────────
    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/")

        # GET /students  →  list all students
        if path == "/students":
            self._respond(200, [student_to_json(s) for s in registry.values()])

        # GET /students/{id}  →  single student
        elif m := re.fullmatch(r"/students/([^/]+)", path):
            uid = m.group(1)
            if uid not in registry:
                return self._respond(404, {"error": f"Student '{uid}' not found."})
            self._respond(200, student_to_json(registry[uid]))

        # GET /honours  →  students with GPA >= 3.5
        elif path == "/honours":
            self._respond(200, [student_to_json(s) for s in get_honours_list(registry)])

        # GET /stats  →  summary numbers for a dashboard
        elif path == "/stats":
            students = list(registry.values())
            gpas = [s.calculate_gpa() for s in students]
            self._respond(200, {
                "total_students": len(students),
                "average_gpa":    round(sum(gpas) / len(gpas), 2) if gpas else 0.0,
                "honours_count":  sum(1 for g in gpas if g >= 3.5),
                "total_enrolments": sum(len(s.courses) for s in students),
            })

        else:
            self._respond(404, {"error": "Route not found."})

    # ──────────────────────────────────────────
    # POST  routes
    # ──────────────────────────────────────────
    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        body = self._read_body()

        # POST /students  →  add a new student
        # Body: { "user_id": "S004", "name": "...", "email": "..." }
        if path == "/students":
            uid   = body.get("user_id", "").strip()
            name  = body.get("name",    "").strip()
            email = body.get("email",   "").strip()
            if not uid or not name or not email:
                return self._respond(400, {"error": "user_id, name and email are required."})
            if uid in registry:
                return self._respond(409, {"error": f"Student ID '{uid}' already exists."})
            registry[uid] = Student(uid, name, email)
            save_database(registry)
            self._respond(201, student_to_json(registry[uid]))

        # POST /students/{id}/grades  →  add or update a grade
        # Body: { "subject": "Math", "score": 88.5 }
        elif m := re.fullmatch(r"/students/([^/]+)/grades", path):
            uid = m.group(1)
            if uid not in registry:
                return self._respond(404, {"error": f"Student '{uid}' not found."})
            subject = body.get("subject", "").strip()
            score   = body.get("score")
            if not subject or score is None:
                return self._respond(400, {"error": "subject and score are required."})
            try:
                registry[uid].add_grade(subject, score)
            except ValueError as e:
                return self._respond(400, {"error": str(e)})
            save_database(registry)
            self._respond(200, student_to_json(registry[uid]))

        # POST /students/{id}/attendance  →  mark attendance
        # Body: { "date": "2024-03-15" }   (omit date to use today)
        elif m := re.fullmatch(r"/students/([^/]+)/attendance", path):
            uid = m.group(1)
            if uid not in registry:
                return self._respond(404, {"error": f"Student '{uid}' not found."})
            from datetime import datetime as dt
            date = body.get("date", "").strip() or dt.now().strftime("%Y-%m-%d")
            registry[uid].mark_attendance(date)
            save_database(registry)
            self._respond(200, student_to_json(registry[uid]))

        # POST /students/{id}/courses  →  enrol in a course
        # Body: { "course": "Calculus II" }
        elif m := re.fullmatch(r"/students/([^/]+)/courses", path):
            uid = m.group(1)
            if uid not in registry:
                return self._respond(404, {"error": f"Student '{uid}' not found."})
            course = body.get("course", "").strip()
            if not course:
                return self._respond(400, {"error": "course name is required."})
            registry[uid].enrol_course(course)
            save_database(registry)
            self._respond(200, student_to_json(registry[uid]))

        # POST /students/{id}/curve  →  apply grade curve
        # Body: { "bonus": 5 }
        elif m := re.fullmatch(r"/students/([^/]+)/curve", path):
            uid = m.group(1)
            if uid not in registry:
                return self._respond(404, {"error": f"Student '{uid}' not found."})
            bonus = body.get("bonus")
            if bonus is None:
                return self._respond(400, {"error": "bonus value is required."})
            try:
                registry[uid].apply_curve(float(bonus))
            except (ValueError, TypeError) as e:
                return self._respond(400, {"error": str(e)})
            save_database(registry)
            self._respond(200, student_to_json(registry[uid]))

        # POST /save  →  force-save database to disk
        elif path == "/save":
            save_database(registry)
            self._respond(200, {"message": "Database saved successfully."})

        else:
            self._respond(404, {"error": "Route not found."})

    # ──────────────────────────────────────────
    # DELETE  routes
    # ──────────────────────────────────────────
    def do_DELETE(self):
        path = urlparse(self.path).path.rstrip("/")

        # DELETE /students/{id}  →  remove a student
        if m := re.fullmatch(r"/students/([^/]+)", path):
            uid = m.group(1)
            if uid not in registry:
                return self._respond(404, {"error": f"Student '{uid}' not found."})
            del registry[uid]
            save_database(registry)
            self._respond(200, {"message": f"Student '{uid}' deleted."})

        else:
            self._respond(404, {"error": "Route not found."})


# ─────────────────────────────────────────────
# Start server
# ─────────────────────────────────────────────
if __name__ == "__main__":
    HOST, PORT = "localhost", 8000
    server = HTTPServer((HOST, PORT), EduTrackHandler)
    print("=" * 50)
    print("  EduTrack API Server")
    print("=" * 50)
    print(f"  Running at  →  http://{HOST}:{PORT}")
    print(f"  Endpoints:")
    print(f"    GET    /students")
    print(f"    GET    /students/{{id}}")
    print(f"    GET    /honours")
    print(f"    GET    /stats")
    print(f"    POST   /students")
    print(f"    POST   /students/{{id}}/grades")
    print(f"    POST   /students/{{id}}/attendance")
    print(f"    POST   /students/{{id}}/courses")
    print(f"    POST   /students/{{id}}/curve")
    print(f"    POST   /save")
    print(f"    DELETE /students/{{id}}")
    print("  Press Ctrl+C to stop.")
    print("=" * 50)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped. Goodbye!")
