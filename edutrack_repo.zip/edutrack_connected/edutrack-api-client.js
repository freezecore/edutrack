/**
 * EduTrack API Client
 * -------------------
 * Paste this <script> block into your Figma-exported HTML file.
 * It connects every UI action to the Python server running at localhost:8000.
 *
 * USAGE:  const api = new EduTrackAPI();
 */

const BASE = "http://localhost:8000";

class EduTrackAPI {

  async _req(method, path, body = null) {
    const opts = {
      method,
      headers: { "Content-Type": "application/json" },
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(BASE + path, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
  }

  // ── READ ──────────────────────────────────────────────────────────────

  /** Get all students */
  getAllStudents()           { return this._req("GET", "/students"); }

  /** Get one student by ID */
  getStudent(id)            { return this._req("GET", `/students/${id}`); }

  /** Get honours list (GPA >= 3.5) */
  getHonours()              { return this._req("GET", "/honours"); }

  /** Get dashboard summary stats */
  getStats()                { return this._req("GET", "/stats"); }

  // ── WRITE ─────────────────────────────────────────────────────────────

  /** Add a new student  –  { user_id, name, email } */
  addStudent(user_id, name, email) {
    return this._req("POST", "/students", { user_id, name, email });
  }

  /** Add or update a grade  –  subject string, score 0-100 */
  addGrade(id, subject, score) {
    return this._req("POST", `/students/${id}/grades`, { subject, score });
  }

  /** Mark attendance  –  date defaults to today if omitted */
  markAttendance(id, date = null) {
    return this._req("POST", `/students/${id}/attendance`, date ? { date } : {});
  }

  /** Enrol in a course */
  enrolCourse(id, course) {
    return this._req("POST", `/students/${id}/courses`, { course });
  }

  /** Apply a grade curve (bonus points, capped at 100) */
  applyCurve(id, bonus) {
    return this._req("POST", `/students/${id}/curve`, { bonus });
  }

  /** Force-save the database to disk */
  save()                    { return this._req("POST", "/save"); }

  // ── DELETE ────────────────────────────────────────────────────────────

  /** Delete a student by ID */
  deleteStudent(id)         { return this._req("DELETE", `/students/${id}`); }
}


// ─────────────────────────────────────────────────────────────────────────────
// EXAMPLE: wire up your Figma-exported HTML buttons to the API
// Replace the selectors below with the actual IDs/classes from your Figma export
// ─────────────────────────────────────────────────────────────────────────────

const api = new EduTrackAPI();

// Helper: show a simple status message (replace with your own UI toast/alert)
function showStatus(msg, isError = false) {
  console[isError ? "error" : "log"](msg);
  // e.g. document.getElementById("status-bar").textContent = msg;
}

// ── Load and display all students on page load ────────────────────────────
async function loadStudents() {
  try {
    const students = await api.getAllStudents();
    // TODO: replace with your Figma list component render logic
    // Example:
    // const list = document.getElementById("student-list");
    // list.innerHTML = students.map(s =>
    //   `<div class="student-card">
    //      <h3>${s.name}</h3>
    //      <p>ID: ${s.user_id} | GPA: ${s.gpa}</p>
    //    </div>`
    // ).join("");
    console.table(students);
  } catch (err) {
    showStatus("Could not load students: " + err.message, true);
  }
}

// ── Load dashboard stats ──────────────────────────────────────────────────
async function loadStats() {
  try {
    const stats = await api.getStats();
    // TODO: bind to your Figma stat cards, e.g.:
    // document.getElementById("total-students").textContent = stats.total_students;
    // document.getElementById("avg-gpa").textContent        = stats.average_gpa;
    // document.getElementById("honours-count").textContent  = stats.honours_count;
    console.log("Stats:", stats);
  } catch (err) {
    showStatus("Could not load stats: " + err.message, true);
  }
}

// ── Add student form submit ───────────────────────────────────────────────
// Wire to your Figma "Add Student" button, e.g.:
// document.getElementById("add-student-btn").addEventListener("click", handleAddStudent);
async function handleAddStudent() {
  // Replace these with your Figma input field selectors
  const uid   = document.getElementById("input-uid").value.trim();
  const name  = document.getElementById("input-name").value.trim();
  const email = document.getElementById("input-email").value.trim();

  try {
    const student = await api.addStudent(uid, name, email);
    showStatus(`Student ${student.name} added!`);
    loadStudents(); // refresh the list
  } catch (err) {
    showStatus("Error: " + err.message, true);
  }
}

// ── Add grade ─────────────────────────────────────────────────────────────
async function handleAddGrade() {
  const uid     = document.getElementById("input-student-id").value.trim();
  const subject = document.getElementById("input-subject").value.trim();
  const score   = parseFloat(document.getElementById("input-score").value);

  try {
    const student = await api.addGrade(uid, subject, score);
    showStatus(`Grade saved. New GPA: ${student.gpa}`);
  } catch (err) {
    showStatus("Error: " + err.message, true);
  }
}

// ── Mark attendance ───────────────────────────────────────────────────────
async function handleMarkAttendance() {
  const uid  = document.getElementById("input-student-id").value.trim();
  const date = document.getElementById("input-date").value || null;

  try {
    await api.markAttendance(uid, date);
    showStatus("Attendance marked!");
  } catch (err) {
    showStatus("Error: " + err.message, true);
  }
}

// ── Kick everything off when the page loads ───────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  loadStats();
  loadStudents();
});
